function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ZJ3gkxEYRd":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

